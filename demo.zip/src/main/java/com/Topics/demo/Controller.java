package com.Topics.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Controller {

	@Autowired
	private LogicInterface logicInterface;

	@RequestMapping(method= RequestMethod.POST, value="/hello/add")
	public List<Entries> addEntries(@RequestBody Entries e) {
		logicInterface.addEntries(e);
		return getAllEntries();
	}

	@RequestMapping("/hello/getAll")
	public List<Entries> getAllEntries() {
		return logicInterface.getAllEntries();
	}

	@RequestMapping("/hello/get/{key}")
	public Entries getEntries(@PathVariable Integer key) {
		return logicInterface.getEntries(key);
	}

	@RequestMapping(method=RequestMethod.PUT, value = "/hello/update")
	public List<Entries> updateEntries(@RequestBody Entries e) {
		logicInterface.updateEntries(e);
		return getAllEntries();
	}

	@RequestMapping(method=RequestMethod.DELETE, value = "/hello/delete/{key}")
	public List<Entries> deleteEntries(@PathVariable Integer key) {
		logicInterface.deleteEntries(key);
		return getAllEntries();
	}

}
