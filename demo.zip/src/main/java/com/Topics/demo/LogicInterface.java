package com.Topics.demo;

import java.util.List;

public interface LogicInterface {

	public void addEntries(Entries e);

	public List<Entries> getAllEntries();

	public Entries getEntries(Integer e);

	public void updateEntries(Entries e);

	public void deleteEntries(Integer e);
}
