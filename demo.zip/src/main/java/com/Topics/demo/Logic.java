package com.Topics.demo;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class Logic implements LogicInterface {

	HashMap<Integer, String> map = new HashMap<>();

	@Override
	public void addEntries(Entries e) {
		map.put(e.getKey(), e.getValue());
	}

	@Override
	public List<Entries> getAllEntries() {
		List<Entries> list = new ArrayList<>();
		for( Map.Entry<Integer, String> map : map.entrySet()) {
			Integer key = map.getKey();
			String v = map.getValue();
			Entries e = new Entries();
			e.setKey(key);
			e.setValue(v);
			list.add(e);
		}
		return list;
	}

	@Override
	public Entries getEntries(Integer key) {
		if(map.containsKey(key)) {
			Entries e = new Entries();
			e.setKey(key);
			e.setValue(map.get(key));
			return e;
		}
		return null;
	}

	@Override
	public void updateEntries(Entries e) {
		map.put(e.getKey(), e.getValue());
	}

	@Override
	public void deleteEntries(Integer i) {
		map.remove(i);
	}
}
